package app.frontEnd.utilities;

/**
 * Created by Ico on 13.1.2017 г..
 */
public class Delete {
}
