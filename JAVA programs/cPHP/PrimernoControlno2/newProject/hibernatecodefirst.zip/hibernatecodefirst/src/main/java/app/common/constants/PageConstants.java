package app.common.constants;


public class PageConstants {
    public static final int SCREEN_HEIGHT = 500;

    public static final int SCREEN_WIDTH = 500;

    public static final int SPACING = 30;
}
