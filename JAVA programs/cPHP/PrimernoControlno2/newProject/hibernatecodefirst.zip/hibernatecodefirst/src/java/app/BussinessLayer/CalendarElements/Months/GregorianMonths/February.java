package app.bussinessLayer.CalendarElements.Months.GregorianMonths;


import app.bussinessLayer.CalendarElements.Months.AbstractMonth;

/**
 * Created by Ico on 3.1.2017 г..
 */
public class February extends AbstractMonth {
    private static final int NUMBER_OF_DAYS_FEBRUARY = 29;

    public February() {
        super(NUMBER_OF_DAYS_FEBRUARY);

    }
}
