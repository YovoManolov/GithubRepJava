package app.frontEnd.views.viewBuilders.interfaces;

import org.springframework.stereotype.Component;


@Component
public interface SceneBuilder {

    void showScene();
}
