package app.frontEnd;

/**
 * Created by Ico on 7.1.2017 г..
 */
public class Delete {
}
