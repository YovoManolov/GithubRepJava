package app.bussinessLayer.models;

/**
 * Created by Ico on 28.12.2016 г..
 */
public class EvetBL {
}
