package app.common.enums;

/**
 * Created by Ico on 28.12.2016 г..
 */
public enum Marker {
    PRIVATE,
    CONFIDENTIAL,
    PERSONAL
}
