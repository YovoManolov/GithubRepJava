package app.frontEnd.utilities.Interfaces;

/**
 * Created by Ico on 11.1.2017 г..
 */
public interface SceneSetter {

}
