package com.restApi.gatewayRestApi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GatewayRestApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
