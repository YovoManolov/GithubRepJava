package app.bussinessLayer.CalendarElements.Months.GregorianMonths;

import app.bussinessLayer.CalendarElements.Months.AbstractMonth;

/**
 * Created by Ico on 3.1.2017 г..
 */
public class Octotober extends AbstractMonth {
    private static final int NUMBER_OF_DAYS_OCTOBER = 31;

    public Octotober() {
        super(NUMBER_OF_DAYS_OCTOBER);
    }
}
