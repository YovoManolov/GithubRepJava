package app.bussinessLayer.CalendarElements.Months.GregorianMonths;

import app.bussinessLayer.CalendarElements.Months.AbstractMonth;

/**
 * Created by Ico on 3.1.2017 г..
 */
public class July extends AbstractMonth {
    private static final int NUMBER_OF_DAYS_JULY = 30;

    public July() {
        super(NUMBER_OF_DAYS_JULY);
    }
}
