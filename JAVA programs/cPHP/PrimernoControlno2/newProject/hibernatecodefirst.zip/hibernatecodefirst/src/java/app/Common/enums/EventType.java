package app.common.enums;

/**
 * Created by Ico on 3.1.2017 г..
 */
public enum EventType {
    MEETING,
    TYPE
}
