package app.bussinessLayer.CalendarElements.CustomCalendar.Interfaces;

import app.bussinessLayer.CalendarElements.Years.Interfaces.Year;

/**
 * Created by Ico on 3.1.2017 г..
 */
public interface EventCalendar {
    Year getYear(int number);
}
