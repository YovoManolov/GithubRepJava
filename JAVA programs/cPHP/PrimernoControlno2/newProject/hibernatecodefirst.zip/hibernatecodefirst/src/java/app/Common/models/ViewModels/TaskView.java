package app.common.models.ViewModels;

/**
 * Created by Ico on 28.12.2016 г..
 */
public class TaskView extends EventView {
    public TaskView() {
        super();
    }
}
