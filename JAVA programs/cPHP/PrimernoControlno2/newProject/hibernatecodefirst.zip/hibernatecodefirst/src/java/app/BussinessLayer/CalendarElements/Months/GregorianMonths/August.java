package app.bussinessLayer.CalendarElements.Months.GregorianMonths;

import app.bussinessLayer.CalendarElements.Months.AbstractMonth;

/**
 * Created by Ico on 3.1.2017 г..
 */
public class August extends AbstractMonth {
    private static final int NUMBER_OF_DAYS_AUGUST = 31;

    public August() {
        super(NUMBER_OF_DAYS_AUGUST);
    }
}
