package app.common.exceptions;

/**
 * Created by Ico on 25.1.2017 г..
 */
public abstract class CreateEventException extends Exception {
    public CreateEventException(String message) {
        super(message);
    }
}
